export type Role = 'guru' | 'santri';

export type AttendanceStatus = 'masuk' | 'keluar' | 'izin';

export type LeaveReason = 'Sakit' | 'Acara Keluarga' | 'Keperluan Pribadi' | 'Lainnya';

export interface AttendanceRecord {
  id: string;
  nama: string;
  peran: Role;
  status: AttendanceStatus;
  alasanIzin?: string;
  keterangan?: string;
  timestamp: string; // ISO string for sorting & filtering
  waktuFormatted: string; // e.g., "07:15 WIB"
  tanggalFormatted: string; // e.g., "22 September 2026"
}

export interface UserSession {
  nama: string;
  peran: Role;
  loginAt: string;
}
