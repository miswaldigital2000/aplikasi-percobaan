import React, { useState, useEffect } from 'react';
import { LogOut, UserCheck, GraduationCap, Clock, Database } from 'lucide-react';
import { UserSession } from '../types';

interface NavbarProps {
  session: UserSession;
  onLogout: () => void;
  supabaseStatus?: {
    connected: boolean;
    tableExists: boolean;
  };
}

export const Navbar: React.FC<NavbarProps> = ({ session, onLogout, supabaseStatus }) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' WIB'
      );
      setDateStr(
        now.toLocaleDateString('id-ID', {
          weekday: 'long',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        })
      );
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const isGuru = session.peran === 'guru';

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-sm shadow-emerald-700/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg sm:text-xl tracking-tight text-slate-900">
                  Presensi Santri
                </span>
                <span className="hidden sm:inline-block text-[11px] font-medium tracking-wide uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Digital
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Sistem Pencatatan Kehadiran & Rekap Terpadu
              </p>
            </div>
          </div>

          {/* Right Actions: Supabase Status, Clock, User Badge, Logout Button */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Supabase Cloud Connection Status */}
            {supabaseStatus && (
              <div
                className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                  supabaseStatus.connected && supabaseStatus.tableExists
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}
                title={
                  supabaseStatus.tableExists
                    ? 'Terhubung ke database Supabase Cloud'
                    : 'Supabase terhubung, tabel absensi perlu dibuat'
                }
              >
                <Database className="w-3.5 h-3.5" />
                <span>Supabase:</span>
                <span className="font-bold">
                  {supabaseStatus.tableExists ? 'Aktif' : 'Setup Tabel'}
                </span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    supabaseStatus.tableExists ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                />
              </div>
            )}

            {/* Live Clock Indicator */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100/80 text-slate-700 border border-slate-200 text-xs">
              <Clock className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
              <span className="font-semibold text-slate-800">{timeStr}</span>
              <span className="text-slate-400">|</span>
              <span className="text-slate-600">{dateStr}</span>
            </div>

            {/* Active User Badge */}
            <div className="flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200">
              <div
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold ${
                  isGuru ? 'bg-indigo-600' : 'bg-emerald-600'
                }`}
              >
                {isGuru ? 'G' : 'S'}
              </div>
              <div className="text-left">
                <p className="text-xs font-bold text-slate-900 leading-tight max-w-[110px] sm:max-w-[160px] truncate">
                  {session.nama}
                </p>
                <span
                  className={`inline-block text-[10px] font-semibold uppercase tracking-wider ${
                    isGuru ? 'text-indigo-600' : 'text-emerald-700'
                  }`}
                >
                  {isGuru ? 'Guru / Ustadz' : 'Santri'}
                </span>
              </div>
            </div>

            {/* Log Out Button */}
            <button
              id="logout-btn"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100/80 border border-red-200 rounded-lg transition-colors duration-150 cursor-pointer shadow-2xs"
              title="Keluar dari sesi dan kembali ke halaman login"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Log Out</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
