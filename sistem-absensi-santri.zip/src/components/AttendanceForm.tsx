import React, { useState, useEffect } from 'react';
import { AttendanceStatus, LeaveReason, AttendanceRecord, Role } from '../types';
import { 
  LogIn, 
  LogOut, 
  FileText, 
  Send, 
  Clock, 
  Calendar, 
  CheckCircle, 
  AlertCircle,
  User,
  Sparkles
} from 'lucide-react';

interface AttendanceFormProps {
  initialNama?: string;
  role: Role;
  onSubmit: (record: Omit<AttendanceRecord, 'id'>) => void;
}

const LEAVE_REASONS: LeaveReason[] = [
  'Sakit',
  'Acara Keluarga',
  'Keperluan Pribadi',
  'Lainnya',
];

export const AttendanceForm: React.FC<AttendanceFormProps> = ({
  initialNama = '',
  role,
  onSubmit,
}) => {
  const [nama, setNama] = useState<string>(initialNama);
  const [status, setStatus] = useState<AttendanceStatus>('masuk');
  const [alasanIzin, setAlasanIzin] = useState<LeaveReason>('Sakit');
  const [keterangan, setKeterangan] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Real-time clock update for live display
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update name if initialNama changes
  useEffect(() => {
    if (initialNama) {
      setNama(initialNama);
    }
  }, [initialNama]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanNama = nama.trim();
    if (!cleanNama) {
      setError('Nama peserta santri wajib diisi.');
      return;
    }

    if (status === 'izin' && !alasanIzin) {
      setError('Silakan pilih alasan izin terlebih dahulu.');
      return;
    }

    const now = new Date();
    const waktuFormatted =
      now.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }) + ' WIB';

    const tanggalFormatted = now.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

    const newRecord: Omit<AttendanceRecord, 'id'> = {
      nama: cleanNama,
      peran: role,
      status,
      alasanIzin: status === 'izin' ? alasanIzin : undefined,
      keterangan: status === 'izin' && keterangan.trim() ? keterangan.trim() : undefined,
      timestamp: now.toISOString(),
      waktuFormatted,
      tanggalFormatted,
    };

    onSubmit(newRecord);

    // Show temporary success feedback
    const statusLabel =
      status === 'masuk' ? 'Jam Masuk' : status === 'keluar' ? 'Jam Keluar' : `Izin (${alasanIzin})`;
    setSuccessMessage(
      `Absensi berhasil dicatat untuk ${cleanNama} [${statusLabel}] pada ${waktuFormatted}.`
    );

    // Reset optional notes
    setKeterangan('');

    setTimeout(() => {
      setSuccessMessage('');
    }, 5000);
  };

  const formattedDateNow = currentTime.toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const formattedTimeNow =
    currentTime.toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }) + ' WIB';

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-7">
      {/* Header Form */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 mb-5 border-b border-slate-100">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>Formulir Absensi Santri</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Pilih status absensi dan kirim data kehadiran Anda hari ini.
          </p>
        </div>

        {/* Real-time automatic timestamp badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-200/70 text-xs w-fit">
          <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
          <div>
            <span className="font-semibold">{formattedTimeNow}</span>
            <span className="mx-1 text-emerald-400">·</span>
            <span className="text-emerald-700">{formattedDateNow}</span>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {successMessage && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-start gap-3 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm">
            <p className="font-bold">Pencatatan Berhasil!</p>
            <p className="mt-0.5 text-emerald-800">{successMessage}</p>
          </div>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* 1. Input Nama Peserta */}
        <div>
          <label
            htmlFor="nama-peserta-input"
            className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5"
          >
            Nama Peserta Santri <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
            <input
              id="nama-peserta-input"
              type="text"
              required
              value={nama}
              onChange={(e) => {
                setNama(e.target.value);
                if (error) setError('');
              }}
              placeholder="Masukkan nama santri..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-slate-900 placeholder:text-slate-400 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
        </div>

        {/* 2. Pilihan Status Absensi: Jam Masuk, Jam Keluar, Izin */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
            Pilihan Status Absensi <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* Jam Masuk */}
            <label
              id="status-masuk-option"
              className={`flex items-center gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all duration-150 ${
                status === 'masuk'
                  ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 shadow-xs ring-1 ring-emerald-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
              }`}
            >
              <input
                type="radio"
                name="attendance-status"
                value="masuk"
                checked={status === 'masuk'}
                onChange={() => setStatus('masuk')}
                className="sr-only"
              />
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  status === 'masuk' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <LogIn className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <span className="block text-sm font-bold leading-tight">Jam Masuk</span>
                <span className="text-[11px] text-slate-500">Mulai kegiatan/KBM</span>
              </div>
            </label>

            {/* Jam Keluar */}
            <label
              id="status-keluar-option"
              className={`flex items-center gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all duration-150 ${
                status === 'keluar'
                  ? 'border-amber-600 bg-amber-50/80 text-amber-950 shadow-xs ring-1 ring-amber-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
              }`}
            >
              <input
                type="radio"
                name="attendance-status"
                value="keluar"
                checked={status === 'keluar'}
                onChange={() => setStatus('keluar')}
                className="sr-only"
              />
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  status === 'keluar' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <LogOut className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <span className="block text-sm font-bold leading-tight">Jam Keluar</span>
                <span className="text-[11px] text-slate-500">Selesai/Pulang</span>
              </div>
            </label>

            {/* Izin */}
            <label
              id="status-izin-option"
              className={`flex items-center gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all duration-150 ${
                status === 'izin'
                  ? 'border-blue-600 bg-blue-50/80 text-blue-950 shadow-xs ring-1 ring-blue-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
              }`}
            >
              <input
                type="radio"
                name="attendance-status"
                value="izin"
                checked={status === 'izin'}
                onChange={() => setStatus('izin')}
                className="sr-only"
              />
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  status === 'izin' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                <FileText className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <span className="block text-sm font-bold leading-tight">Izin</span>
                <span className="text-[11px] text-slate-500">Berhalangan hadir</span>
              </div>
            </label>
          </div>
        </div>

        {/* 3. Logika Kondisional Izin: Tampilkan kolom/dropdown baru otomatis jika "Izin" dipilih */}
        {status === 'izin' && (
          <div
            id="conditional-izin-panel"
            className="p-4 rounded-xl bg-blue-50/60 border border-blue-200 space-y-3.5 transition-all animate-fadeIn"
          >
            <div className="flex items-center gap-2 text-blue-900 font-semibold text-xs uppercase tracking-wider">
              <AlertCircle className="w-4 h-4 text-blue-600" />
              <span>Detail Informasi Izin</span>
            </div>

            <div>
              <label
                htmlFor="alasan-izin-select"
                className="block text-xs font-bold text-slate-700 mb-1.5"
              >
                Pilih Alasan Izin <span className="text-red-500">*</span>
              </label>
              <select
                id="alasan-izin-select"
                value={alasanIzin}
                onChange={(e) => setAlasanIzin(e.target.value as LeaveReason)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-blue-300 bg-white text-slate-900 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                {LEAVE_REASONS.map((reason) => (
                  <option key={reason} value={reason}>
                    {reason}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="keterangan-izin-input"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Keterangan Tambahan (Opsional)
              </label>
              <input
                id="keterangan-izin-input"
                type="text"
                value={keterangan}
                onChange={(e) => setKeterangan(e.target.value)}
                placeholder="Misal: Sakit demam flu / ada urusan keluarga di rumah..."
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 placeholder:text-slate-400 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        )}

        {/* Error message */}
        {error && (
          <p className="text-xs font-semibold text-red-600 flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </p>
        )}

        {/* 4. Tombol Kirim/Submit dengan Stempel Tanggal & Waktu Otomatis */}
        <div className="pt-2">
          <button
            type="submit"
            id="submit-absensi-btn"
            className="w-full sm:w-auto min-w-[220px] px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Kirim Absensi Sekarang</span>
          </button>
          <p className="text-[11px] text-slate-400 mt-2">
            * Waktu dan tanggal presensi akan otomatis direkam dari waktu lokal saat tombol ditekan.
          </p>
        </div>
      </form>
    </div>
  );
};
