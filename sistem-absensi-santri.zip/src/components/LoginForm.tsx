import React, { useState } from 'react';
import { Role, UserSession } from '../types';
import { GraduationCap, ShieldCheck, UserCheck, ArrowRight, BookOpen, Clock, CheckCircle2 } from 'lucide-react';
import { PRESET_SANTRI_NAMES } from '../data/initialData';

interface LoginFormProps {
  onLogin: (session: UserSession) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [selectedRole, setSelectedRole] = useState<Role>('santri');
  const [nama, setNama] = useState<string>('Ahmad Fauzi');
  const [error, setError] = useState<string>('');

  const handleRoleChange = (role: Role) => {
    setSelectedRole(role);
    setError('');
    if (role === 'guru') {
      setNama('Ustadz Ahmad Mansur, S.Pd.I');
    } else {
      setNama('Ahmad Fauzi');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = nama.trim();
    if (!cleanName) {
      setError('Silakan masukkan nama lengkap terlebih dahulu.');
      return;
    }

    onLogin({
      nama: cleanName,
      peran: selectedRole,
      loginAt: new Date().toISOString(),
    });
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-lg">
        {/* Header Intro */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-700/20 mb-4">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Sistem Absensi Santri
          </h1>
          <p className="mt-2 text-sm text-slate-600 max-w-sm mx-auto">
            Silakan pilih peran Anda dan masukkan nama untuk memulai absensi atau memantau kehadiran.
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-lg shadow-slate-200/50 p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Role Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                Pilih Peran (Role)
              </label>
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                {/* Santri Card */}
                <button
                  type="button"
                  id="role-santri-btn"
                  onClick={() => handleRoleChange('santri')}
                  className={`p-4 rounded-xl border-2 text-left transition-all duration-150 cursor-pointer relative ${
                    selectedRole === 'santri'
                      ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                        selectedRole === 'santri'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <UserCheck className="w-5 h-5" />
                    </div>
                    {selectedRole === 'santri' && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    )}
                  </div>
                  <h3 className="font-bold text-base leading-tight">Santri</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Isi absensi masuk, keluar, atau izin harian.
                  </p>
                </button>

                {/* Guru Card */}
                <button
                  type="button"
                  id="role-guru-btn"
                  onClick={() => handleRoleChange('guru')}
                  className={`p-4 rounded-xl border-2 text-left transition-all duration-150 cursor-pointer relative ${
                    selectedRole === 'guru'
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                        selectedRole === 'guru'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    {selectedRole === 'guru' && (
                      <CheckCircle2 className="w-5 h-5 text-indigo-600" />
                    )}
                  </div>
                  <h3 className="font-bold text-base leading-tight">Guru / Ustadz</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Akses seluruh rekap & data absensi santri.
                  </p>
                </button>
              </div>
            </div>

            {/* Nama Input */}
            <div>
              <label
                htmlFor="user-nama"
                className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2"
              >
                {selectedRole === 'santri' ? 'Nama Santri' : 'Nama Guru / Ustadz'}
              </label>
              <div className="relative">
                <input
                  id="user-nama"
                  type="text"
                  value={nama}
                  onChange={(e) => {
                    setNama(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder={
                    selectedRole === 'santri'
                      ? 'Contoh: Ahmad Fauzi'
                      : 'Contoh: Ustadz Ahmad Mansur'
                  }
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm font-medium transition-colors"
                />
              </div>

              {/* Quick Suggestion Chips for Santri */}
              {selectedRole === 'santri' && (
                <div className="mt-3">
                  <p className="text-xs text-slate-500 mb-1.5 font-medium">
                    Pilih cepat nama contoh santri:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_SANTRI_NAMES.slice(0, 5).map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => {
                          setNama(preset);
                          setError('');
                        }}
                        className={`text-xs px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                          nama === preset
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300 font-semibold'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {error && <p className="mt-2 text-xs font-semibold text-red-600">{error}</p>}
            </div>

            {/* Submit / Login Button */}
            <button
              type="submit"
              id="submit-login-btn"
              className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm text-white flex items-center justify-center gap-2 shadow-sm transition-all duration-150 cursor-pointer ${
                selectedRole === 'guru'
                  ? 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 shadow-indigo-600/25'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 shadow-emerald-600/25'
              }`}
            >
              <span>
                Masuk Sebagai {selectedRole === 'guru' ? 'Guru / Ustadz' : 'Santri'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Notice Info */}
          <div className="mt-6 pt-5 border-t border-slate-100 flex items-start gap-2.5 text-slate-500 text-xs">
            <Clock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p>
              Setiap catatan absensi akan merekam waktu presensi secara otomatis dan disimpan secara
              langsung di sistem.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
