import React, { useState, useMemo } from 'react';
import { AttendanceRecord, UserSession } from '../types';
import { AttendanceTable } from './AttendanceTable';
import { AttendanceForm } from './AttendanceForm';
import { 
  Users, 
  LogIn, 
  LogOut, 
  FileText, 
  ShieldCheck, 
  PlusCircle, 
  ChevronDown, 
  ChevronUp,
  BarChart3,
  CalendarDays
} from 'lucide-react';

interface TeacherDashboardProps {
  session: UserSession;
  records: AttendanceRecord[];
  onAddRecord: (record: Omit<AttendanceRecord, 'id'>) => void;
  onDeleteRecord: (id: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  session,
  records,
  onAddRecord,
  onDeleteRecord,
}) => {
  const [showManualForm, setShowManualForm] = useState<boolean>(false);

  // Stats calculation
  const stats = useMemo(() => {
    const total = records.length;
    const masuk = records.filter((r) => r.status === 'masuk').length;
    const keluar = records.filter((r) => r.status === 'keluar').length;
    const izin = records.filter((r) => r.status === 'izin').length;

    // Unique santri count
    const uniqueSantri = new Set(
      records.filter((r) => r.peran === 'santri').map((r) => r.nama.toLowerCase().trim())
    ).size;

    return { total, masuk, keluar, izin, uniqueSantri };
  }, [records]);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-semibold mb-3">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Panel Khusus Guru / Ustadz</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
              Ahlan wa Sahlan, {session.nama}
            </h1>
            <p className="text-indigo-200/80 text-xs sm:text-sm mt-1 max-w-xl">
              Anda memiliki hak akses penuh untuk memantau seluruh catatan kehadiran, jam masuk, jam
              keluar, serta permohonan izin seluruh santri secara langsung.
            </p>
          </div>

          {/* Action to toggle manual input form */}
          <button
            type="button"
            id="toggle-manual-form-btn"
            onClick={() => setShowManualForm(!showManualForm)}
            className="self-start sm:self-auto inline-flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 active:bg-white/30 text-white text-xs sm:text-sm font-semibold rounded-xl border border-white/20 transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-emerald-400" />
            <span>{showManualForm ? 'Tutup Form Tambah' : 'Input Absensi Santri'}</span>
            {showManualForm ? (
              <ChevronUp className="w-4 h-4 ml-1" />
            ) : (
              <ChevronDown className="w-4 h-4 ml-1" />
            )}
          </button>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Catatan */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Absensi
            </span>
            <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {stats.total}
            </span>
            <span className="text-xs text-slate-500">({stats.uniqueSantri} Santri)</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Akumulasi seluruh catatan</p>
        </div>

        {/* Jam Masuk */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Jam Masuk
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
              <LogIn className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-700">
              {stats.masuk}
            </span>
            <span className="text-xs text-emerald-600 font-semibold">Tercatat</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Kehadiran masuk santri</p>
        </div>

        {/* Jam Keluar */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
              Jam Keluar
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
              <LogOut className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-700">
              {stats.keluar}
            </span>
            <span className="text-xs text-amber-600 font-semibold">Tercatat</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Kepulangan / selesai KBM</p>
        </div>

        {/* Izin */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
              Izin / Sakit
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-700">
              {stats.izin}
            </span>
            <span className="text-xs text-blue-600 font-semibold">Santri</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Dengan rincian alasan</p>
        </div>
      </div>

      {/* Optional Manual Entry for Teacher */}
      {showManualForm && (
        <div className="p-1 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-indigo-500/20 to-teal-500/20 animate-fadeIn">
          <AttendanceForm
            role="santri"
            onSubmit={(newRecord) => {
              onAddRecord(newRecord);
            }}
          />
        </div>
      )}

      {/* Main Full Rekap Table */}
      <AttendanceTable
        records={records}
        isGuru={true}
        onDeleteRecord={onDeleteRecord}
        title="Seluruh Rekap Data Absensi Santri"
        subtitle="Daftar lengkap kehadiran santri beserta status, alasan izin, waktu, dan stempel tanggal."
      />
    </div>
  );
};
