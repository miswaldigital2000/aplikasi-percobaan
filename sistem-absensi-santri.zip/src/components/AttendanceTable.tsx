import React, { useState, useMemo } from 'react';
import { AttendanceRecord, AttendanceStatus, Role } from '../types';
import { 
  Search, 
  Filter, 
  LogIn, 
  LogOut, 
  FileText, 
  Clock, 
  Calendar, 
  Download, 
  Trash2, 
  UserCheck, 
  ShieldCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface AttendanceTableProps {
  records: AttendanceRecord[];
  isGuru: boolean;
  onDeleteRecord?: (id: string) => void;
  title?: string;
  subtitle?: string;
}

export const AttendanceTable: React.FC<AttendanceTableProps> = ({
  records,
  isGuru,
  onDeleteRecord,
  title = 'Tabel Rekap Data Absensi',
  subtitle,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'semua' | AttendanceStatus>('semua');
  const [roleFilter, setRoleFilter] = useState<'semua' | Role>('semua');

  // Filtered list
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      // Search by name
      const matchesSearch = r.nama.toLowerCase().includes(searchQuery.toLowerCase());
      // Filter by status
      const matchesStatus = statusFilter === 'semua' || r.status === statusFilter;
      // Filter by role
      const matchesRole = roleFilter === 'semua' || r.peran === roleFilter;

      return matchesSearch && matchesStatus && matchesRole;
    });
  }, [records, searchQuery, statusFilter, roleFilter]);

  // Export to CSV helper
  const handleExportCSV = () => {
    if (filteredRecords.length === 0) return;

    const headers = ['No', 'Nama', 'Peran', 'Status', 'Alasan Izin', 'Keterangan', 'Waktu', 'Tanggal'];
    const rows = filteredRecords.map((r, idx) => [
      idx + 1,
      `"${r.nama.replace(/"/g, '""')}"`,
      r.peran === 'guru' ? 'Guru' : 'Santri',
      r.status === 'masuk' ? 'Jam Masuk' : r.status === 'keluar' ? 'Jam Keluar' : 'Izin',
      `"${(r.alasanIzin || '-').replace(/"/g, '""')}"`,
      `"${(r.keterangan || '-').replace(/"/g, '""')}"`,
      `"${r.waktuFormatted}"`,
      `"${r.tanggalFormatted}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `rekap_absensi_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: AttendanceStatus) => {
    switch (status) {
      case 'masuk':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <LogIn className="w-3.5 h-3.5 text-emerald-600" />
            <span>Jam Masuk</span>
          </span>
        );
      case 'keluar':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <LogOut className="w-3.5 h-3.5 text-amber-600" />
            <span>Jam Keluar</span>
          </span>
        );
      case 'izin':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <FileText className="w-3.5 h-3.5 text-blue-600" />
            <span>Izin</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      {/* Header & Controls */}
      <div className="p-5 sm:p-6 border-b border-slate-100">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <span>{title}</span>
              <span className="px-2 py-0.5 text-xs font-semibold bg-slate-100 text-slate-700 rounded-full border border-slate-200">
                {filteredRecords.length} Data
              </span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {subtitle ||
                (isGuru
                  ? 'Akses penuh guru: Menampilkan seluruh rekap catatan absensi santri & ustadz.'
                  : 'Daftar riwayat pencatatan absensi yang telah tersimpan.')}
            </p>
          </div>

          {/* Export Action */}
          {isGuru && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="export-csv-btn"
                onClick={handleExportCSV}
                disabled={filteredRecords.length === 0}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                title="Unduh data dalam format CSV untuk Excel atau laporan"
              >
                <Download className="w-3.5 h-3.5 text-slate-600" />
                <span>Ekspor CSV</span>
              </button>
            </div>
          )}
        </div>

        {/* Filter & Search Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 mt-4">
          {/* Search Box */}
          <div className="sm:col-span-6 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari berdasarkan nama santri..."
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            >
              <option value="semua">Semua Status</option>
              <option value="masuk">Jam Masuk</option>
              <option value="keluar">Jam Keluar</option>
              <option value="izin">Izin</option>
            </select>
          </div>

          {/* Role Filter for Guru */}
          {isGuru ? (
            <div className="sm:col-span-3">
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              >
                <option value="semua">Semua Peran</option>
                <option value="santri">Khusus Santri</option>
                <option value="guru">Khusus Guru</option>
              </select>
            </div>
          ) : (
            <div className="sm:col-span-3 flex items-center">
              <span className="text-xs text-slate-500">
                Menampilkan data absensi pribadi
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs sm:text-sm">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-3.5 px-4 sm:px-6 w-12 text-center">No</th>
              <th className="py-3.5 px-4 sm:px-6">Nama Peserta</th>
              <th className="py-3.5 px-4 sm:px-6">Peran</th>
              <th className="py-3.5 px-4 sm:px-6">Status Absensi</th>
              <th className="py-3.5 px-4 sm:px-6">Alasan Izin</th>
              <th className="py-3.5 px-4 sm:px-6">Waktu & Tanggal Input</th>
              {isGuru && onDeleteRecord && (
                <th className="py-3.5 px-4 sm:px-6 text-center w-16">Aksi</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredRecords.length === 0 ? (
              <tr>
                <td
                  colSpan={isGuru && onDeleteRecord ? 7 : 6}
                  className="py-12 text-center text-slate-500"
                >
                  <div className="flex flex-col items-center justify-center gap-2">
                    <AlertCircle className="w-8 h-8 text-slate-300" />
                    <p className="font-semibold text-slate-700">Tidak ada data absensi ditemukan</p>
                    <p className="text-xs text-slate-400">
                      {searchQuery || statusFilter !== 'semua'
                        ? 'Coba sesuaikan kata kunci pencarian atau filter status.'
                        : 'Belum ada catatan absensi yang direkam.'}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredRecords.map((record, index) => (
                <tr
                  key={record.id}
                  className="hover:bg-slate-50/70 transition-colors duration-100"
                >
                  {/* Index */}
                  <td className="py-3.5 px-4 sm:px-6 text-center text-slate-400 font-mono text-xs">
                    {index + 1}
                  </td>

                  {/* Nama */}
                  <td className="py-3.5 px-4 sm:px-6 font-bold text-slate-900">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${
                          record.peran === 'guru'
                            ? 'bg-indigo-100 text-indigo-700'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {record.nama.charAt(0).toUpperCase()}
                      </div>
                      <span className="truncate max-w-[180px] sm:max-w-xs">{record.nama}</span>
                    </div>
                  </td>

                  {/* Peran */}
                  <td className="py-3.5 px-4 sm:px-6">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold uppercase tracking-wider ${
                        record.peran === 'guru'
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {record.peran === 'guru' ? (
                        <>
                          <ShieldCheck className="w-3 h-3" />
                          <span>Guru</span>
                        </>
                      ) : (
                        <>
                          <UserCheck className="w-3 h-3" />
                          <span>Santri</span>
                        </>
                      )}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="py-3.5 px-4 sm:px-6">{getStatusBadge(record.status)}</td>

                  {/* Alasan Izin (jika ada) */}
                  <td className="py-3.5 px-4 sm:px-6">
                    {record.status === 'izin' ? (
                      <div className="text-xs">
                        <span className="font-semibold text-blue-900 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200 inline-block">
                          {record.alasanIzin || 'Izin'}
                        </span>
                        {record.keterangan && (
                          <p className="text-[11px] text-slate-500 mt-1 italic max-w-xs truncate">
                            "{record.keterangan}"
                          </p>
                        )}
                      </div>
                    ) : (
                      <span className="text-slate-300 font-mono">-</span>
                    )}
                  </td>

                  {/* Waktu & Tanggal Input */}
                  <td className="py-3.5 px-4 sm:px-6 text-slate-600">
                    <div className="flex flex-col text-xs">
                      <div className="flex items-center gap-1 font-semibold text-slate-800">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{record.waktuFormatted}</span>
                      </div>
                      <span className="text-[11px] text-slate-500 mt-0.5">
                        {record.tanggalFormatted}
                      </span>
                    </div>
                  </td>

                  {/* Delete Action (for Guru) */}
                  {isGuru && onDeleteRecord && (
                    <td className="py-3.5 px-4 sm:px-6 text-center">
                      <button
                        type="button"
                        onClick={() => onDeleteRecord(record.id)}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                        title="Hapus baris catatan ini"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="p-4 bg-slate-50/60 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
        <span>Menampilkan {filteredRecords.length} dari total {records.length} rekaman presensi.</span>
        <span className="text-[11px] text-slate-400">Pembaruan data otomatis tersimpan di peramban</span>
      </div>
    </div>
  );
};
