import React, { useState } from 'react';
import { Database, CheckCircle2, AlertTriangle, Copy, Check, RefreshCw, ExternalLink, ChevronDown, ChevronUp } from 'lucide-react';
import { SUPABASE_SETUP_SQL } from '../lib/supabase';

interface SupabaseStatusBannerProps {
  connected: boolean;
  tableExists: boolean;
  onRefresh: () => void;
  isChecking: boolean;
}

export const SupabaseStatusBanner: React.FC<SupabaseStatusBannerProps> = ({
  connected,
  tableExists,
  onRefresh,
  isChecking,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [expanded, setExpanded] = useState<boolean>(false);

  const handleCopySQL = () => {
    navigator.clipboard.writeText(SUPABASE_SETUP_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  // If connected and table exists, show a sleek mini status badge or collapsible bar
  if (connected && tableExists) {
    return (
      <div className="mb-5 flex items-center justify-between px-4 py-2.5 rounded-xl bg-emerald-50/90 border border-emerald-200 text-emerald-900 text-xs">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-bold">Supabase Cloud Database:</span>
          <span className="inline-flex items-center gap-1 font-medium text-emerald-700">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Terhubung & Tabel 'absensi' Siap Digunakan
          </span>
        </div>
        <button
          onClick={onRefresh}
          disabled={isChecking}
          className="inline-flex items-center gap-1 font-semibold text-emerald-700 hover:text-emerald-800 transition-colors cursor-pointer"
          title="Sinkronkan data terbaru dari Supabase"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">Sinkronkan</span>
        </button>
      </div>
    );
  }

  // If table is missing, show a helpful setup guide with copy SQL button
  return (
    <div className="mb-6 rounded-2xl bg-amber-50/90 border border-amber-300 text-amber-950 p-4 sm:p-5 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700 shrink-0 mt-0.5">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-slate-900">
                Supabase Terhubung: Tabel 'absensi' Perlu Dibuat
              </h4>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded-md bg-amber-200 text-amber-900">
                Tindakan Diperlukan
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Koneksi ke proyek Supabase Anda telah aktif, namun tabel <code>public.absensi</code> belum ditemukan.
              Jalankan script SQL di bawah ini di <strong>SQL Editor Supabase</strong> Anda untuk mengaktifkan sinkronisasi cloud.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <button
            type="button"
            onClick={onRefresh}
            disabled={isChecking}
            className="px-3 py-1.5 rounded-lg border border-amber-300 bg-white hover:bg-amber-100/50 text-amber-900 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
            <span>{isChecking ? 'Memeriksa...' : 'Cek Status'}</span>
          </button>
          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
          >
            <span>{expanded ? 'Tutup Script' : 'Lihat Script SQL'}</span>
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="mt-4 pt-4 border-t border-amber-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <span>Langkah 1: Salin Query SQL di bawah ini</span>
            </div>
            <button
              type="button"
              onClick={handleCopySQL}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Berhasil Disalin!' : 'Salin SQL'}</span>
            </button>
          </div>

          <div className="relative">
            <pre className="p-3.5 bg-slate-900 text-slate-100 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800 leading-relaxed">
              {SUPABASE_SETUP_SQL}
            </pre>
          </div>

          <div className="text-xs text-slate-600 space-y-1">
            <p><strong>Langkah 2:</strong> Buka tab <a href="https://supabase.com/dashboard/project/lppadfvojcryvvryjecc/sql/new" target="_blank" rel="noreferrer" className="text-emerald-700 font-bold underline inline-flex items-center gap-0.5">SQL Editor Supabase <ExternalLink className="w-3 h-3 inline" /></a>.</p>
            <p><strong>Langkah 3:</strong> Tempelkan (Paste) query di atas lalu klik tombol <strong>Run</strong>.</p>
            <p><strong>Langkah 4:</strong> Kembali ke sini dan klik tombol <strong>"Cek Status"</strong>. Semua data absensi otomatis tersinkronisasi ke cloud!</p>
          </div>
        </div>
      )}
    </div>
  );
};
