import React, { useMemo } from 'react';
import { AttendanceRecord, UserSession } from '../types';
import { AttendanceForm } from './AttendanceForm';
import { AttendanceTable } from './AttendanceTable';
import { UserCheck, CheckCircle2, Clock, Calendar, Sparkles } from 'lucide-react';

interface SantriDashboardProps {
  session: UserSession;
  records: AttendanceRecord[];
  onAddRecord: (record: Omit<AttendanceRecord, 'id'>) => void;
}

export const SantriDashboard: React.FC<SantriDashboardProps> = ({
  session,
  records,
  onAddRecord,
}) => {
  // Filter records belonging to this santri
  const myRecords = useMemo(() => {
    return records.filter(
      (r) => r.nama.toLowerCase().trim() === session.nama.toLowerCase().trim()
    );
  }, [records, session.nama]);

  // Today's latest attendance for this santri
  const latestToday = myRecords[0];

  return (
    <div className="space-y-6">
      {/* Greeting Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-950 rounded-2xl p-6 sm:p-7 text-white shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-xs font-semibold mb-3">
              <UserCheck className="w-3.5 h-3.5" />
              <span>Portal Absensi Santri</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
              Assalamu'alaikum, {session.nama}
            </h1>
            <p className="text-emerald-100/80 text-xs sm:text-sm mt-1 max-w-xl">
              Silakan isi formulir di bawah ini untuk mencatat jam masuk, jam keluar, atau permohonan
              izin belajar Anda.
            </p>
          </div>

          {/* Quick status badge if already submitted */}
          {latestToday && (
            <div className="bg-white/10 backdrop-blur border border-white/20 rounded-xl p-3 text-xs">
              <span className="text-emerald-300 font-semibold block mb-0.5">
                Status Terakhir Anda:
              </span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white capitalize">
                  {latestToday.status === 'masuk'
                    ? 'Jam Masuk'
                    : latestToday.status === 'keluar'
                    ? 'Jam Keluar'
                    : `Izin (${latestToday.alasanIzin})`}
                </span>
                <span className="text-emerald-200">({latestToday.waktuFormatted})</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Attendance Form */}
        <div className="lg:col-span-6">
          <AttendanceForm
            initialNama={session.nama}
            role="santri"
            onSubmit={onAddRecord}
          />
        </div>

        {/* Right Column: Personal Attendance History */}
        <div className="lg:col-span-6">
          <AttendanceTable
            records={myRecords}
            isGuru={false}
            title="Riwayat Absensi Saya"
            subtitle={`Catatan riwayat kehadiran khusus atas nama ${session.nama}.`}
          />
        </div>
      </div>
    </div>
  );
};
