import React, { useState, useEffect, useCallback } from 'react';
import { UserSession, AttendanceRecord } from './types';
import { INITIAL_ATTENDANCE_DATA } from './data/initialData';
import { Navbar } from './components/Navbar';
import { LoginForm } from './components/LoginForm';
import { TeacherDashboard } from './components/TeacherDashboard';
import { SantriDashboard } from './components/SantriDashboard';
import { SupabaseStatusBanner } from './components/SupabaseStatusBanner';
import {
  supabase,
  fetchAttendanceFromSupabase,
  insertAttendanceToSupabase,
  deleteAttendanceFromSupabase,
  mapRowToAttendanceRecord,
  SupabaseRow,
} from './lib/supabase';

const STORAGE_SESSION_KEY = 'pesantren_absensi_session_v1';
const STORAGE_RECORDS_KEY = 'pesantren_absensi_records_v1';

export default function App() {
  const [session, setSession] = useState<UserSession | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SESSION_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [records, setRecords] = useState<AttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_RECORDS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_ATTENDANCE_DATA;
  });

  const [supabaseStatus, setSupabaseStatus] = useState<{
    connected: boolean;
    tableExists: boolean;
  }>({
    connected: true,
    tableExists: false,
  });
  const [isCheckingSupabase, setIsCheckingSupabase] = useState<boolean>(false);

  // Check Supabase connection and load cloud data
  const syncSupabaseData = useCallback(async () => {
    setIsCheckingSupabase(true);
    const result = await fetchAttendanceFromSupabase();
    setIsCheckingSupabase(false);

    if (result.tableExists) {
      setSupabaseStatus({ connected: true, tableExists: true });
      if (result.data && result.data.length > 0) {
        setRecords(result.data);
      }
    } else {
      setSupabaseStatus({ connected: true, tableExists: false });
    }
  }, []);

  // Initial load from Supabase
  useEffect(() => {
    syncSupabaseData();
  }, [syncSupabaseData]);

  // Real-time listener for Supabase table changes
  useEffect(() => {
    if (!supabaseStatus.tableExists) return;

    const channel = supabase
      .channel('public:absensi')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'absensi' },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newRecord = mapRowToAttendanceRecord(payload.new as SupabaseRow);
            setRecords((prev) => {
              // Avoid duplicates
              if (prev.some((r) => r.id === newRecord.id)) return prev;
              return [newRecord, ...prev];
            });
          } else if (payload.eventType === 'DELETE') {
            const deletedId = payload.old.id;
            setRecords((prev) => prev.filter((r) => r.id !== String(deletedId)));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabaseStatus.tableExists]);

  // Persist records to localStorage as backup
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_RECORDS_KEY, JSON.stringify(records));
    } catch (e) {
      console.error('Gagal menyimpan rekaman absensi ke storage', e);
    }
  }, [records]);

  // Persist session on change
  useEffect(() => {
    try {
      if (session) {
        localStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
      } else {
        localStorage.removeItem(STORAGE_SESSION_KEY);
      }
    } catch (e) {
      console.error('Gagal menyimpan sesi login', e);
    }
  }, [session]);

  const handleLogin = (newSession: UserSession) => {
    setSession(newSession);
  };

  const handleLogout = () => {
    setSession(null);
  };

  const handleAddRecord = async (recordData: Omit<AttendanceRecord, 'id'>) => {
    const tempId = `att-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    const optimisticRecord: AttendanceRecord = {
      ...recordData,
      id: tempId,
    };

    // Update UI immediately (optimistic)
    setRecords((prev) => [optimisticRecord, ...prev]);

    // Send to Supabase cloud if table is ready
    if (supabaseStatus.tableExists) {
      const { data, error } = await insertAttendanceToSupabase(recordData);
      if (data) {
        // Replace temp ID with actual Supabase ID
        setRecords((prev) =>
          prev.map((r) => (r.id === tempId ? data : r))
        );
      } else if (error) {
        console.warn('Gagal menyimpan ke Supabase, tersimpan lokal:', error.message);
      }
    }
  };

  const handleDeleteRecord = async (id: string) => {
    // Delete from state immediately
    setRecords((prev) => prev.filter((r) => r.id !== id));

    // Delete from Supabase if table is ready
    if (supabaseStatus.tableExists) {
      const { error } = await deleteAttendanceFromSupabase(id);
      if (error) {
        console.warn('Gagal menghapus dari Supabase:', error.message);
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Navbar appears after user successfully logs in */}
      {session && (
        <Navbar
          session={session}
          onLogout={handleLogout}
          supabaseStatus={supabaseStatus}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {!session ? (
          <div className="space-y-6">
            <SupabaseStatusBanner
              connected={supabaseStatus.connected}
              tableExists={supabaseStatus.tableExists}
              onRefresh={syncSupabaseData}
              isChecking={isCheckingSupabase}
            />
            <LoginForm onLogin={handleLogin} />
          </div>
        ) : (
          <div>
            <SupabaseStatusBanner
              connected={supabaseStatus.connected}
              tableExists={supabaseStatus.tableExists}
              onRefresh={syncSupabaseData}
              isChecking={isCheckingSupabase}
            />

            {session.peran === 'guru' ? (
              <TeacherDashboard
                session={session}
                records={records}
                onAddRecord={handleAddRecord}
                onDeleteRecord={handleDeleteRecord}
              />
            ) : (
              <SantriDashboard
                session={session}
                records={records}
                onAddRecord={handleAddRecord}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="py-4 border-t border-slate-200/80 text-center text-xs text-slate-500 bg-white/60">
        <p>
          Sistem Absensi Santri &copy; {new Date().getFullYear()} &mdash; Terintegrasi dengan{' '}
          <span className="font-semibold text-emerald-700">Supabase Cloud PostgreSQL</span>
        </p>
      </footer>
    </div>
  );
}
