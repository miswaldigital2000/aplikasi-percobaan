import { createClient } from '@supabase/supabase-js';
import { AttendanceRecord } from '../types';

const SUPABASE_URL =
  import.meta.env.VITE_SUPABASE_URL || 'https://lppadfvojcryvvryjecc.supabase.co';
const SUPABASE_ANON_KEY =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxwcGFkZnZvamNyeXZ2cnlqZWNjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAwNzU1ODcsImV4cCI6MjEwNTY1MTU4N30.PTWNWUlmWvuu3s8mZDG9tKHqsVfZ-g1zeXUCsS_0Rm8';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export interface SupabaseRow {
  id: string;
  nama: string;
  peran: string;
  status: string;
  alasan_izin: string | null;
  keterangan: string | null;
  created_at?: string;
  timestamp?: string;
  waktu_formatted: string | null;
  tanggal_formatted: string | null;
}

export function mapRowToAttendanceRecord(row: SupabaseRow): AttendanceRecord {
  return {
    id: String(row.id),
    nama: row.nama || 'Tanpa Nama',
    peran: (row.peran as any) || 'santri',
    status: (row.status as any) || 'masuk',
    alasanIzin: row.alasan_izin || undefined,
    keterangan: row.keterangan || undefined,
    timestamp: row.created_at || row.timestamp || new Date().toISOString(),
    waktuFormatted: row.waktu_formatted || '',
    tanggalFormatted: row.tanggal_formatted || '',
  };
}

export async function fetchAttendanceFromSupabase(): Promise<{
  data: AttendanceRecord[] | null;
  error: Error | null;
  tableExists: boolean;
}> {
  try {
    const { data, error } = await supabase
      .from('absensi')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      // PGRST205 or 42P01 is Postgres/PostgREST code for table not found
      const isMissingTable =
        error.code === 'PGRST205' ||
        error.code === '42P01' ||
        error.message.toLowerCase().includes('could not find the table') ||
        error.message.toLowerCase().includes('relation "absensi" does not exist') ||
        error.message.toLowerCase().includes('not found');
      return { data: null, error: new Error(error.message), tableExists: !isMissingTable };
    }

    const mapped = (data as SupabaseRow[]).map(mapRowToAttendanceRecord);
    return { data: mapped, error: null, tableExists: true };
  } catch (err: any) {
    return { data: null, error: err, tableExists: false };
  }
}

export async function insertAttendanceToSupabase(
  record: Omit<AttendanceRecord, 'id'>
): Promise<{ data: AttendanceRecord | null; error: Error | null }> {
  try {
    const rowToInsert = {
      nama: record.nama,
      peran: record.peran,
      status: record.status,
      alasan_izin: record.alasanIzin || null,
      keterangan: record.keterangan || null,
      waktu_formatted: record.waktuFormatted,
      tanggal_formatted: record.tanggalFormatted,
      created_at: record.timestamp || new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('absensi')
      .insert([rowToInsert])
      .select()
      .single();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: mapRowToAttendanceRecord(data as SupabaseRow), error: null };
  } catch (err: any) {
    return { data: null, error: err };
  }
}

export async function deleteAttendanceFromSupabase(
  id: string
): Promise<{ success: boolean; error: Error | null }> {
  try {
    const { error } = await supabase.from('absensi').delete().eq('id', id);
    if (error) {
      return { success: false, error: new Error(error.message) };
    }
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err };
  }
}

export const SUPABASE_SETUP_SQL = `-- Jalankan query ini di SQL Editor Supabase Anda:
CREATE TABLE IF NOT EXISTS absensi (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nama TEXT NOT NULL,
  peran TEXT NOT NULL CHECK (peran IN ('guru', 'santri')),
  status TEXT NOT NULL CHECK (status IN ('masuk', 'keluar', 'izin')),
  alasan_izin TEXT,
  keterangan TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  waktu_formatted TEXT,
  tanggal_formatted TEXT
);

-- Mengaktifkan Row Level Security (RLS)
ALTER TABLE absensi ENABLE ROW LEVEL SECURITY;

-- Izinkan pembacaan dan penambahan data presensi
CREATE POLICY "Izinkan baca semua absensi" ON absensi FOR SELECT USING (true);
CREATE POLICY "Izinkan tambah data absensi" ON absensi FOR INSERT WITH CHECK (true);
CREATE POLICY "Izinkan hapus absensi" ON absensi FOR DELETE USING (true);
`;
