import { AttendanceRecord } from '../types';

export const INITIAL_ATTENDANCE_DATA: AttendanceRecord[] = [
  {
    id: 'att-1',
    nama: 'Ahmad Fauzi',
    peran: 'santri',
    status: 'masuk',
    timestamp: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
    waktuFormatted: '06:45 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  },
  {
    id: 'att-2',
    nama: 'Muhammad Rizky',
    peran: 'santri',
    status: 'masuk',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2.5).toISOString(),
    waktuFormatted: '07:05 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  },
  {
    id: 'att-3',
    nama: 'Nurul Hidayah',
    peran: 'santri',
    status: 'izin',
    alasanIzin: 'Sakit',
    keterangan: 'Demam tinggi dan istirahat di asrama',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    waktuFormatted: '07:20 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  },
  {
    id: 'att-4',
    nama: 'Fatimah Az-Zahra',
    peran: 'santri',
    status: 'masuk',
    timestamp: new Date(Date.now() - 3600 * 1000 * 1.8).toISOString(),
    waktuFormatted: '07:25 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  },
  {
    id: 'att-5',
    nama: 'Zaidan Al-Farisi',
    peran: 'santri',
    status: 'izin',
    alasanIzin: 'Acara Keluarga',
    keterangan: 'Pernikahan kakak kandung di luar kota',
    timestamp: new Date(Date.now() - 3600 * 1000 * 1.2).toISOString(),
    waktuFormatted: '07:45 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  },
  {
    id: 'att-6',
    nama: 'Hasan Basri',
    peran: 'santri',
    status: 'keluar',
    timestamp: new Date(Date.now() - 3600 * 1000 * 0.5).toISOString(),
    waktuFormatted: '11:30 WIB',
    tanggalFormatted: new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(new Date()),
  }
];

export const PRESET_SANTRI_NAMES = [
  'Ahmad Fauzi',
  'Muhammad Rizky',
  'Nurul Hidayah',
  'Fatimah Az-Zahra',
  'Zaidan Al-Farisi',
  'Hasan Basri',
  'Aisyah Rahmawati',
  'Bilal Habasyi',
  'Khadijah Putri',
  'Salman Al-Farisi'
];
